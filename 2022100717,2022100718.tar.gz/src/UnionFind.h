#if !defined(_UF_H_)
#define _UF_H_

#include "Ponto.h"

int UF_find(pPonto *vet, int i);

int UF_union(pPonto *vet, int p, int q);

#endif // _UF_H_

