# MST minimum spanning tree (movimento sem terra)

Nao ha nenhuma letra 'j' no nosso trabalho!